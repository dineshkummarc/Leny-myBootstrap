<?php

require('includes/connection.php');
require('session.php');
if (isset($_POST['btnlogin'])) {


  $users = trim($_POST['user']);
  $upass = trim($_POST['password']);
  $h_upass = MD5($upass);
if ($upass == ''){
     ?>    <script type="text/javascript">
                alert("Password is missing!");
                window.location = "userlogin.php";
                </script>
        <?php
}else{
//create some sql statement             
        $sql = "SELECT * FROM  `user` WHERE  `username` =  '" . $users . "' AND  `password` =  '" . $h_upass . "'";
        $result = $db->query($sql);

        if ($result){
        //get the number of results based n the sql statement
        //check the number of result, if equal to one   
        //IF theres a result
            if ( $result->num_rows > 0) {
                //store the result to a array and passed to variable found_user
                $found_user  = mysqli_fetch_array($result);

                //fill the result to session variable
                $_SESSION['MEMBER_ID1']  = $found_user['id']; 
                $_SESSION['firstname'] = $found_user['firstname']; 
                $_SESSION['lastname']  =  $found_user['lastname']; 
           
             ?>    <script type="text/javascript">
                      //then it will be redirected to index.php
                      window.location = "homepage1.php";
                  </script>
             <?php        
           
        
            } else {
            //IF theres no result
              ?>    <script type="text/javascript">
                alert("Username or Password Not Registered! Contact Your administrator.");
                window.location = "index.php";
                </script>
        <?php

            }

         } else {
                 # code...
        echo "Error: " . $sql . "<br>" . $db->error;
        }
        
    }       
} 
 $db->close();
?>